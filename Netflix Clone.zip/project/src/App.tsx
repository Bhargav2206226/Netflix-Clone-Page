import React, { useState, useEffect } from 'react';
import NetflixLogin from './components/NetflixLogin';
import NetflixHome from './components/NetflixHome';

function App() {
  const [isSignedIn, setIsSignedIn] = useState(false);

  useEffect(() => {
    const handleSignInSuccess = () => {
      setIsSignedIn(true);
    };

    window.addEventListener('netflix-signin-success', handleSignInSuccess);
    
    return () => {
      window.removeEventListener('netflix-signin-success', handleSignInSuccess);
    };
  }, []);

  return isSignedIn ? <NetflixHome /> : <NetflixLogin />;
}

export default App;