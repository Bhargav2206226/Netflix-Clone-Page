import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface FormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

interface FormErrors {
  email?: string;
  password?: string;
}

export default function NetflixLogin() {
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
    rememberMe: false,
  });
  
  const [errors, setErrors] = useState<FormErrors>({});
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email) || /^\d{10,}$/.test(email); // Email or phone number
  };

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.email.trim()) {
      newErrors.email = 'Please enter a valid email address or phone number.';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address or phone number.';
    }

    if (!formData.password) {
      newErrors.password = 'Your password must contain between 4 and 60 characters.';
    } else if (formData.password.length < 4 || formData.password.length > 60) {
      newErrors.password = 'Your password must contain between 4 and 60 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      // Trigger sign in success
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('netflix-signin-success'));
      }
    }, 2000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear errors when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({...prev, [name]: undefined}));
    }
  };

  return (
    <div className="min-h-screen bg-black bg-opacity-75 relative">
      {/* Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.8)), url('https://images.pexels.com/photos/265685/pexels-photo-265685.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop')`
        }}
      />
      
      {/* Header */}
      <header className="relative z-10 px-4 py-6 lg:px-16">
        <div className="flex items-center">
          <div className="text-red-600 text-2xl lg:text-4xl font-bold">
            NETFLIX
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">
          <div className="bg-black bg-opacity-75 px-8 py-12 rounded-md">
            <h1 className="text-white text-3xl font-bold mb-8">Sign In</h1>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Email Input */}
              <div className="relative">
                <input
                  type="text"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="Email or phone number"
                  className={`w-full px-4 py-4 bg-gray-700 text-white rounded border-0 focus:outline-none focus:ring-2 ${
                    errors.email ? 'focus:ring-red-500 ring-2 ring-red-500' : 'focus:ring-white'
                  } placeholder-gray-400`}
                />
                {errors.email && (
                  <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                )}
              </div>

              {/* Password Input */}
              <div className="relative">
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Password"
                    className={`w-full px-4 py-4 bg-gray-700 text-white rounded border-0 focus:outline-none focus:ring-2 ${
                      errors.password ? 'focus:ring-red-500 ring-2 ring-red-500' : 'focus:ring-white'
                    } placeholder-gray-400 pr-12`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white focus:outline-none"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                )}
              </div>

              {/* Sign In Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-red-800 text-white font-semibold py-4 rounded transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 focus:ring-offset-black"
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Signing In...
                  </div>
                ) : (
                  'Sign In'
                )}
              </button>

              {/* Remember Me */}
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center text-gray-300 cursor-pointer">
                  <input
                    type="checkbox"
                    name="rememberMe"
                    checked={formData.rememberMe}
                    onChange={handleInputChange}
                    className="mr-2 rounded border-gray-300 text-white bg-gray-700 focus:ring-red-500 focus:ring-offset-0"
                  />
                  Remember me
                </label>
                <a 
                  href="#" 
                  className="text-gray-300 hover:text-white hover:underline focus:outline-none focus:underline"
                >
                  Need help?
                </a>
              </div>
            </form>

            {/* Sign Up Link */}
            <div className="mt-16 text-gray-400">
              <span>New to Netflix? </span>
              <a 
                href="#" 
                className="text-white hover:underline font-medium focus:outline-none focus:underline"
              >
                Sign up now
              </a>
              .
            </div>

            {/* reCAPTCHA Notice */}
            <div className="mt-4 text-xs text-gray-500">
              <p>
                This page is protected by Google reCAPTCHA to ensure you're not a bot.{' '}
                <a href="#" className="text-blue-500 hover:underline">
                  Learn more.
                </a>
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 px-4 py-8 lg:px-16 text-gray-500 text-sm">
        <div className="max-w-6xl mx-auto">
          <p className="mb-6">Questions? Call 1-844-542-4813</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="space-y-2">
              <a href="#" className="block hover:underline">FAQ</a>
              <a href="#" className="block hover:underline">Investor Relations</a>
              <a href="#" className="block hover:underline">Privacy</a>
              <a href="#" className="block hover:underline">Speed Test</a>
            </div>
            <div className="space-y-2">
              <a href="#" className="block hover:underline">Help Center</a>
              <a href="#" className="block hover:underline">Jobs</a>
              <a href="#" className="block hover:underline">Cookie Preferences</a>
              <a href="#" className="block hover:underline">Legal Notices</a>
            </div>
            <div className="space-y-2">
              <a href="#" className="block hover:underline">Account</a>
              <a href="#" className="block hover:underline">Ways to Watch</a>
              <a href="#" className="block hover:underline">Corporate Information</a>
              <a href="#" className="block hover:underline">Only on Netflix</a>
            </div>
            <div className="space-y-2">
              <a href="#" className="block hover:underline">Media Center</a>
              <a href="#" className="block hover:underline">Terms of Use</a>
              <a href="#" className="block hover:underline">Contact Us</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}