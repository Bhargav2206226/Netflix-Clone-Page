import React, { useState } from 'react';
import { Play, Plus, ThumbsUp, ChevronDown, Search, Bell, User } from 'lucide-react';

interface Movie {
  id: number;
  title: string;
  poster: string;
  year: string;
  rating: string;
  genre: string;
  description: string;
}

const movies: Movie[] = [
  {
    id: 1,
    title: "Stranger Things",
    poster: "https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=400&h=600&fit=crop",
    year: "2023",
    rating: "TV-14",
    genre: "Sci-Fi Drama",
    description: "A group of young friends witness supernatural forces and secret government exploits."
  },
  {
    id: 2,
    title: "The Crown",
    poster: "https://images.pexels.com/photos/8111357/pexels-photo-8111357.jpeg?auto=compress&cs=tinysrgb&w=400&h=600&fit=crop",
    year: "2023",
    rating: "TV-MA",
    genre: "Historical Drama",
    description: "The political rivalries and romance of Queen Elizabeth II's reign."
  },
  {
    id: 3,
    title: "Dark",
    poster: "https://images.pexels.com/photos/7991225/pexels-photo-7991225.jpeg?auto=compress&cs=tinysrgb&w=400&h=600&fit=crop",
    year: "2023",
    rating: "TV-MA",
    genre: "Mystery Thriller",
    description: "A family saga with a supernatural twist set in a German town."
  },
  {
    id: 4,
    title: "Bridgerton",
    poster: "https://images.pexels.com/photos/8111240/pexels-photo-8111240.jpeg?auto=compress&cs=tinysrgb&w=400&h=600&fit=crop",
    year: "2023",
    rating: "TV-MA",
    genre: "Period Romance",
    description: "The romantic lives of the Bridgerton family in Regency-era London."
  }
];

export default function NetflixHome() {
  const [hoveredMovie, setHoveredMovie] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-gradient-to-b from-black to-transparent px-4 lg:px-16 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="text-red-600 text-2xl lg:text-3xl font-bold">
              NETFLIX
            </div>
            <nav className="hidden md:flex space-x-6 text-sm">
              <a href="#" className="hover:text-gray-300 transition-colors">Home</a>
              <a href="#" className="hover:text-gray-300 transition-colors">TV Shows</a>
              <a href="#" className="hover:text-gray-300 transition-colors">Movies</a>
              <a href="#" className="hover:text-gray-300 transition-colors">New & Popular</a>
              <a href="#" className="hover:text-gray-300 transition-colors">My List</a>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <Search className="w-5 h-5 cursor-pointer hover:text-gray-300 transition-colors" />
            <Bell className="w-5 h-5 cursor-pointer hover:text-gray-300 transition-colors" />
            <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center cursor-pointer">
              <User className="w-5 h-5" />
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `linear-gradient(77deg, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.4) 40%, rgba(0,0,0,0.8) 100%), url('https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop')`
          }}
        />
        <div className="relative z-10 px-4 lg:px-16 max-w-2xl">
          <h1 className="text-4xl lg:text-6xl font-bold mb-4">Stranger Things</h1>
          <p className="text-lg lg:text-xl mb-6 text-gray-200">
            When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.
          </p>
          <div className="flex space-x-4">
            <button className="flex items-center bg-white text-black px-8 py-3 rounded font-semibold hover:bg-gray-200 transition-colors">
              <Play className="w-5 h-5 mr-2 fill-current" />
              Play
            </button>
            <button className="flex items-center bg-gray-600 bg-opacity-70 text-white px-8 py-3 rounded font-semibold hover:bg-opacity-50 transition-colors">
              <Plus className="w-5 h-5 mr-2" />
              My List
            </button>
          </div>
        </div>
      </section>

      {/* Movies Section */}
      <section className="px-4 lg:px-16 py-12 -mt-32 relative z-20">
        <h2 className="text-2xl lg:text-3xl font-bold mb-8">Popular on Netflix</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {movies.map((movie) => (
            <div
              key={movie.id}
              className="relative group cursor-pointer transform transition-all duration-300 hover:scale-105"
              onMouseEnter={() => setHoveredMovie(movie.id)}
              onMouseLeave={() => setHoveredMovie(null)}
            >
              <div className="relative overflow-hidden rounded-lg">
                <img
                  src={movie.poster}
                  alt={movie.title}
                  className="w-full h-64 lg:h-80 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Hover Overlay */}
                {hoveredMovie === movie.id && (
                  <div className="absolute inset-0 flex flex-col justify-end p-4 bg-gradient-to-t from-black via-black/50 to-transparent">
                    <h3 className="text-lg font-bold mb-2">{movie.title}</h3>
                    <div className="flex items-center space-x-2 mb-2 text-sm text-gray-300">
                      <span className="bg-gray-700 px-2 py-1 rounded text-xs">{movie.rating}</span>
                      <span>{movie.year}</span>
                      <span>•</span>
                      <span>{movie.genre}</span>
                    </div>
                    <p className="text-sm text-gray-300 mb-3 line-clamp-2">{movie.description}</p>
                    <div className="flex items-center space-x-2">
                      <button className="w-8 h-8 bg-white rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors">
                        <Play className="w-4 h-4 text-black fill-current ml-0.5" />
                      </button>
                      <button className="w-8 h-8 bg-gray-700 bg-opacity-70 rounded-full flex items-center justify-center hover:bg-opacity-50 transition-colors">
                        <Plus className="w-4 h-4" />
                      </button>
                      <button className="w-8 h-8 bg-gray-700 bg-opacity-70 rounded-full flex items-center justify-center hover:bg-opacity-50 transition-colors">
                        <ThumbsUp className="w-4 h-4" />
                      </button>
                      <button className="w-8 h-8 bg-gray-700 bg-opacity-70 rounded-full flex items-center justify-center hover:bg-opacity-50 transition-colors ml-auto">
                        <ChevronDown className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Trending Now Section */}
      <section className="px-4 lg:px-16 py-12">
        <h2 className="text-2xl lg:text-3xl font-bold mb-8">Trending Now</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {movies.slice().reverse().map((movie) => (
            <div
              key={`trending-${movie.id}`}
              className="relative group cursor-pointer transform transition-all duration-300 hover:scale-105"
            >
              <div className="relative overflow-hidden rounded-lg">
                <img
                  src={movie.poster}
                  alt={movie.title}
                  className="w-full h-64 lg:h-80 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-4 left-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <h3 className="text-lg font-bold">{movie.title}</h3>
                  <p className="text-sm text-gray-300">{movie.year} • {movie.genre}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 lg:px-16 py-12 text-gray-400 text-sm border-t border-gray-800">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div className="space-y-3">
              <a href="#" className="block hover:text-white transition-colors">Audio Description</a>
              <a href="#" className="block hover:text-white transition-colors">Help Center</a>
              <a href="#" className="block hover:text-white transition-colors">Gift Cards</a>
              <a href="#" className="block hover:text-white transition-colors">Media Center</a>
            </div>
            <div className="space-y-3">
              <a href="#" className="block hover:text-white transition-colors">Investor Relations</a>
              <a href="#" className="block hover:text-white transition-colors">Jobs</a>
              <a href="#" className="block hover:text-white transition-colors">Terms of Use</a>
              <a href="#" className="block hover:text-white transition-colors">Privacy</a>
            </div>
            <div className="space-y-3">
              <a href="#" className="block hover:text-white transition-colors">Legal Notices</a>
              <a href="#" className="block hover:text-white transition-colors">Cookie Preferences</a>
              <a href="#" className="block hover:text-white transition-colors">Corporate Information</a>
              <a href="#" className="block hover:text-white transition-colors">Contact Us</a>
            </div>
            <div className="space-y-3">
              <button className="border border-gray-600 px-4 py-2 text-sm hover:border-white transition-colors">
                Service Code
              </button>
            </div>
          </div>
          <p className="text-xs text-gray-500">© 1997-2024 Netflix, Inc.</p>
        </div>
      </footer>
    </div>
  );
}